var GameScreen = function(assetManager, stage) {
    "use strict";
    
    // custom event for next button
    var eventScreenComplete = new createjs.Event("endFinished");
    var eventScreenPrevious = new createjs.Event("endPrevious");
    // construct container to hold all sprites of screen
    var screen = new createjs.Container();
    
    
    // add background to screen
    var background = assetManager.getSprite("uiAssets");
    background.gotoAndStop("gameScreen");
    screen.addChild(background);
    
    var ghost1 = assetManager.getSprite("uiAssets");
    var ghostMover1 = assetManager.getSprite("uiAssets");
    
    // construct hitspot sprite
    var hitAreaSprite = assetManager.getSprite("uiAssets");
    
    var counter = document.querySelector('.counter');
    var btn = document.querySelector('.btn');
    var running = false;
    
    	
        ghost1 = assetManager.getSprite("uiAssets");
		ghost1.x = 250;
		ghost1.y = 250;
		ghost1.gotoAndStop("ghostAlive");
		stage.addChild(ghost1);
		ghostMover1 = new Mover(ghost1, stage);
		ghostMover1.setSpeed(6);
		ghostMover1.startMe();
		ghostMover1.setDirection(1)

    // Count down to start the game
    function countdown(num) {
      if (!num) {
        // This code runs when you're out of time
        alert("Time Over, I Knew You Wouldn't Last! Restart The Timer, If You Dare");
        running = false;} else {
        // This code runs while there is still time
        setTimeout(function() {
          // Recursive call to the same function
          return countdown(num - 1);
        }, 1000);
      }
      counter.innerText = num;
    }

    btn.addEventListener('click', ()=> {
      if (!running) {
          // Amount of time set
        countdown(10);
          console.log("Timer Is Running You Have Exactly 10 Seconds");
          // While it is running
        running = true;
      }
    });
    

    // ---------------------------------- public methods
    this.showMe = function() {
        // anything else that needs to be done when the screen is shown!
        // ...
        stage.addChild(screen);
    }
    
    this.hideMe = function() {
        stage.removeChild(screen);
    } 
    
    function onTick(e){
        ghostMover1.updateMe();
    }
};